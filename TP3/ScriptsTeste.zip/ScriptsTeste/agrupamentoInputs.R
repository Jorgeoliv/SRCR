#import das librarias
library( neuralnet )
library( hydroGOF )
library( leaps )
library( arules )

#import do dataset utilizado
dados <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)
dadosReais <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)

#Conver��o dos atributos para num�ricos
dados$job <- as.numeric(dados$job)
dados$marital <- as.numeric(dados$marital)
dados$education <- as.numeric(dados$education) 
dados$default <- as.numeric(dados$default)
dados$housing <- as.numeric(dados$housing)
dados$loan <- as.numeric(dados$loan)
dados$contact <- as.numeric(dados$contact)
dados$month <- as.numeric(dados$month)
dados$day_of_week <- as.numeric(dados$day_of_week)
dados$poutcome <- as.numeric(dados$poutcome)
dados$y <- as.numeric(dados$y)

#Defini��o dos dados de teste e de treino
treino <- dados[1:3001,]
teste <- dados[3002:4119,]

summary(dados)
plot(dados$nr.employed)


#Discretize dos dados
#N�o efetuamos discretiza��o no loan, housing, campaign, poutcome, emp.var.rate
dados$age <- c(discretize(dados$age, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$job <- c(discretize(dados$job, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$marital <- c(discretize(dados$marital, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$eduaction <- c(discretize(dados$education, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$month <- c(discretize(dados$month, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$day_of_week <- c(discretize(dados$day_of_week, categories = 2, labels = c(1,2), ordered=FALSE))
dados$cons.price.idx <- c(discretize(dados$cons.price.idx, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$cons.conf.idx <- c(discretize(dados$cons.conf.idx, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$euribor3m <- c(discretize(dados$euribor3m, categories = 4, labels = c(1,2,3,4), ordered=FALSE))

#defini��o da fun��o para sele��o de dados
funcao <- y ~ age+job+marital+education+housing+loan+month+day_of_week+campaign+poutcome+emp.var.rate+cons.price.idx+cons.conf.idx+euribor3m+nr.employed

#uso do regsubsets default
selecao <- regsubsets(funcao,dados)
summary(selecao)
#selecao: age, education, month, campaign, poutcome, cons.price.idx, cons.conf.idx, nr.eployed

#formula para treino da RNA
formula <- y ~ age+education+month+campaign+poutcome+cons.price.idx+cons.conf.idx+nr.employed

#Treino e teste da RNA
rna <- neuralnet( formula,treino,hidden=c(4, 2), lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","campaign","education","month","poutcome","cons.price.idx","cons.conf.idx","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "rprop-", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","cons.conf.idx","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "sag", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.conf.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino, hidden=c(4,2), algorithm = "slr", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","cons.conf.idx","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

