#import das librarias
library( neuralnet )
library( hydroGOF )
library( leaps )
library( arules )

#import do dataset utilizado
dados <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)
dadosReais <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)

#Conver��o dos atributos para num�ricos
dados$job <- as.numeric(dados$job)
dados$marital <- as.numeric(dados$marital)
dados$education <- as.numeric(dados$education) 
dados$default <- as.numeric(dados$default)
dados$housing <- as.numeric(dados$housing)
dados$loan <- as.numeric(dados$loan)
dados$contact <- as.numeric(dados$contact)
dados$month <- as.numeric(dados$month)
dados$day_of_week <- as.numeric(dados$day_of_week)
dados$poutcome <- as.numeric(dados$poutcome)
dados$y <- as.numeric(dados$y)

#------------- - - - - - - - - -  -  -  -  -  -  -  -    -    -    -    -
#Teste com o uso de todas as vari�veis de input

#Defini��o dos dados de teste e de treino
treino <- dados[1:3001,]
teste <- dados[3002:4119,]

#formula para treino da RNA
formula <- y ~ age+job+marital+education+default+housing+loan+month+day_of_week+campaign+pdays+previous+poutcome+emp.var.rate+cons.price.idx+cons.conf.idx+euribor3m+nr.employed

#Treino e teste da RNA
rna <- neuralnet( formula,treino,hidden=c(4, 2), lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","job","marital","education","default","housing","loan","month","day_of_week","campaign","pdays","previous","poutcome","emp.var.rate","cons.price.idx","cons.conf.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.32
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "backprop", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","job","marital","education","default","housing","loan","month","day_of_week","campaign","pdays","previous","poutcome","emp.var.rate","cons.price.idx","cons.conf.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.32
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "rprop+", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","job","marital","education","default","housing","loan","month","day_of_week","campaign","pdays","previous","poutcome","emp.var.rate","cons.price.idx","cons.conf.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.33
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "rprop-", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","job","marital","education","default","housing","loan","month","day_of_week","campaign","pdays","previous","poutcome","emp.var.rate","cons.price.idx","cons.conf.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "sag", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","job","marital","education","default","housing","loan","month","day_of_week","campaign","pdays","previous","poutcome","emp.var.rate","cons.price.idx","cons.conf.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino, hidden=c(4,2), algorithm = "slr", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","job","marital","education","default","housing","loan","month","day_of_week","campaign","pdays","previous","poutcome","emp.var.rate","cons.price.idx","cons.conf.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"









#------------- - - - - - - - - -  -  -  -  -  -  -  -    -    -    -    -
#Teste com o input de vri�veis reduzidas

#defini��o da fun��o para sele��o de dados
funcao <- y ~ age+job+marital+education+default+housing+loan+month+day_of_week+campaign+pdays+previous+poutcome+emp.var.rate+cons.price.idx+cons.conf.idx+euribor3m+nr.employed

#uso do regsubsets default
selecao <- regsubsets(funcao,dados, force.out = 2)
summary(selecao)
#Selecionou -> month, pdays, previous, poutcome, emp.var.rate, cons.price.idx, euribor3m, nr.employed

#Defini��o dos dados de teste e de treino
treino <- dados[1:3001,]
teste <- dados[3002:4119,]

#formula para treino da RNA
formula <- y ~ month+pdays+previous+poutcome+emp.var.rate+cons.price.idx+euribor3m+nr.employed

#Treino e teste da RNA
rna <- neuralnet( formula,treino,hidden=c(4, 2), lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("month","pdays","previous","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "rprop-", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("month","pdays","previous","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "sag", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("month","pdays","previous","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino, hidden=c(4,2), algorithm = "slr", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("month","pdays","previous","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"







#------------- - - - - - - - - -  -  -  -  -  -  -  -    -    -    -    -
#Teste com o input de vri�veis reduzidas e sem vicios

#defini��o da fun��o para sele��o de dados
funcao <- y ~ age+job+marital+education+housing+loan+month+day_of_week+campaign+poutcome+emp.var.rate+cons.price.idx+cons.conf.idx+euribor3m+nr.employed

#uso do regsubsets default
selecao <- regsubsets(funcao,dados, force.out = 2)
summary(selecao)
#Selecionou -> age, education, month, poutcome, emp.var.rate, cons.price.idx, euribor3m, nr.employed

#Defini��o dos dados de teste e de treino
treino <- dados[1:3001,]
teste <- dados[3002:4119,]

#formula para treino da RNA
formula <- y ~ age+education+month+poutcome+emp.var.rate+cons.price.idx+euribor3m+nr.employed

#Treino e teste da RNA
rna <- neuralnet( formula,treino,hidden=c(4, 2), lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "rprop-", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "sag", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"

rna <- neuralnet( formula,treino, hidden=c(4,2), algorithm = "slr", lifesign="full", threshold=0.1)
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA (n�o conseguiu calcular)
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� possui valores "1" -> "no"
