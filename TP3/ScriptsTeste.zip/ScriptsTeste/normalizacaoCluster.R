library( neuralnet )
library( hydroGOF )
library( leaps )
library( arules )

dados <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)
dadosReais <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)


dados$job <- as.numeric(dados$job)
dados$marital <- as.numeric(dados$marital)
dados$education <- as.numeric(dados$education) 
dados$default <- as.numeric(dados$default)
dados$housing <- as.numeric(dados$housing)
dados$loan <- as.numeric(dados$loan)
dados$contact <- as.numeric(dados$contact)
dados$month <- as.numeric(dados$month)
dados$day_of_week <- as.numeric(dados$day_of_week)
dados$poutcome <- as.numeric(dados$poutcome)
dados$y <- as.numeric(dados$y)

#Discretize dos dados
#N�o efetuamos discretiza��o no loan, housing, campaign, poutcome, emp.var.rate
dados$age <- c(discretize(dados$age, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$job <- c(discretize(dados$job, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$marital <- c(discretize(dados$marital, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$eduaction <- c(discretize(dados$education, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$month <- c(discretize(dados$month, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$day_of_week <- c(discretize(dados$day_of_week, categories = 2, labels = c(1,2), ordered=FALSE))
dados$cons.price.idx <- c(discretize(dados$cons.price.idx, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$cons.conf.idx <- c(discretize(dados$cons.conf.idx, categories = 4, labels = c(1,2,3,4), ordered=FALSE))
dados$euribor3m <- c(discretize(dados$euribor3m, categories = 4, labels = c(1,2,3,4), ordered=FALSE))

#normalizar entre -1 e 1
dados$age <- (dados$age - (max(dados$age)+min(dados$age))/2)/((max(dados$age)-min(dados$age))/2)
dados$job <- (dados$job - (max(dados$job)+min(dados$job))/2)/((max(dados$job)-min(dados$job))/2)
dados$marital <- (dados$marital - (max(dados$marital)+min(dados$marital))/2)/((max(dados$marital)-min(dados$marital))/2)
dados$education <- (dados$education - (max(dados$education)+min(dados$education))/2)/((max(dados$education)-min(dados$education))/2)
dados$housing <- (dados$housing - (max(dados$housing)+min(dados$housing))/2)/((max(dados$housing)-min(dados$housing))/2)
dados$loan <- (dados$loan - (max(dados$loan)+min(dados$loan))/2)/((max(dados$loan)-min(dados$loan))/2)
dados$month <- (dados$month - (max(dados$month)+min(dados$month))/2)/((max(dados$month)-min(dados$month))/2)
dados$day_of_week <- (dados$day_of_week - (max(dados$day_of_week)+min(dados$day_of_week))/2)/((max(dados$day_of_week)-min(dados$day_of_week))/2)
dados$campaign <- (dados$campaign - (max(dados$campaign)+min(dados$campaign))/2)/((max(dados$campaign)-min(dados$campaign))/2)
dados$poutcome <- (dados$poutcome - (max(dados$poutcome)+min(dados$poutcome))/2)/((max(dados$poutcome)-min(dados$poutcome))/2)
dados$emp.var.rate <- (dados$emp.var.rate - (max(dados$emp.var.rate)+min(dados$emp.var.rate))/2)/((max(dados$emp.var.rate)-min(dados$emp.var.rate))/2)
dados$cons.price.idx <- (dados$cons.price.idx - (max(dados$cons.price.idx)+min(dados$cons.price.idx))/2)/((max(dados$cons.price.idx)-min(dados$cons.price.idx))/2)
dados$cons.conf.idx <- (dados$cons.conf.idx - (max(dados$cons.conf.idx)+min(dados$cons.conf.idx))/2)/((max(dados$cons.conf.idx)-min(dados$cons.conf.idx))/2)
dados$euribor3m <- (dados$euribor3m - (max(dados$euribor3m)+min(dados$euribor3m))/2)/((max(dados$euribor3m)-min(dados$euribor3m))/2)
dados$nr.employed <- (dados$nr.employed - (max(dados$nr.employed)+min(dados$nr.employed))/2)/((max(dados$nr.employed)-min(dados$nr.employed))/2)

treino <- dados[1:3001,]
teste <- dados[3002:4119,]

funcao <- y ~ age+job+marital+education+housing+loan+month+day_of_week+campaign+poutcome+emp.var.rate+cons.price.idx+cons.conf.idx+euribor3m+nr.employed

selecao <- regsubsets(funcao,dados)
summary(selecao)
#selecao: age, education, month, poutcome, emp.var.rate, cons.price.idx, euribor3m, nr.employed

formula <- y ~ age+education+month+campaign+poutcome+emp.var.rate+cons.price.idx+nr.employed

#Treino e teste da RNA
rna <- neuralnet( formula,treino,hidden=c(4, 2), lifesign="full", threshold=0.1)
#5775 steps, 23 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","campaign","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.326
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 364.9
ssq(c(teste$y),c(resultados$previsao))
#resultado: 119
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 9 entradas com o valor de 2 -> "yes", cerca de 0,8%

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "rprop-", lifesign="full", threshold=0.1)
#step: 893, 3,5 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.43
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 158.1
ssq(c(teste$y),c(resultados$previsao))
#resultado: 205
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 89 entradas com o valor de 2 -> "yes", cerca de 7,9%


rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "sag", lifesign="full", threshold=0.1)
#steps 51995 e 4 minutos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.365
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 222.2
ssq(c(teste$y),c(resultados$previsao))
#resultado: 149
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 31 entradas com o valor de 2 -> "yes", cerca de 2,77%

rna <- neuralnet( formula,treino, hidden=c(4,2), algorithm = "slr", lifesign="full", threshold=0.1)
#steps 2783 e 12 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.325
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 207.8
ssq(c(teste$y),c(resultados$previsao))
#resultado: 118
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 28 entradas com o valor de 2 -> "yes", cerca de 2,5%

rna <- neuralnet( formula,treino, algorithm = "slr", lifesign="full", threshold=0.1)
#steps 2783 e 12 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: NA
ssq(c(teste$y),c(resultados$previsao))
#resultado: 207.8
diferentes <- resultados$previsao[resultados$previsao != 1]
#s� com valores de "1" -> "no"

rna <- neuralnet( formula,treino, hidden=c(10,5 ,2), algorithm = "slr", lifesign="full", threshold=0.1)
#n�o convergiu


