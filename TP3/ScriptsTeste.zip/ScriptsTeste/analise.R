library( neuralnet )
library( hydroGOF )
library( leaps )
library( arules )

dados <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)
dadosReais <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)


dados$job <- as.numeric(dados$job)
dados$marital <- as.numeric(dados$marital)
dados$education <- as.numeric(dados$education) 
dados$default <- as.numeric(dados$default)
dados$housing <- as.numeric(dados$housing)
dados$loan <- as.numeric(dados$loan)
dados$contact <- as.numeric(dados$contact)
dados$month <- as.numeric(dados$month)
dados$day_of_week <- as.numeric(dados$day_of_week)
dados$poutcome <- as.numeric(dados$poutcome)
dados$y <- as.numeric(dados$y)

desvPad <- apply(dados, 2, sd)
View(desvPad)

#O previous tamb�m pode ser vicioso, o minimo � 0, a media � muito proxima de zero porqe tem 3523 entradas a zero
quantosPrevious <- dadosReais$previous[dadosReais$previous==0]
view(quantosCampanha)

#3315 entradas com o valor de 1 para o default
quantosDefault <- dados$default[dados$default==1]

quantosMarital <- dados$marital[dados$marital==2]

quantosEmpVarRate <- dados$emp.var.rate[dados$emp.var.rate==1.4]

#3349 de dados loan
quantosLoan <- dados$loan[dados$loan==1]