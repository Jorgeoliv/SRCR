library( neuralnet )
library( hydroGOF )
library( leaps )
library( arules )

dados <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)
dadosReais <- read.table(
  "C:\\Users\\jorge\\Desktop\\UM\\3_ANO\\2-SEMESTRE\\SRCR\\Trabalho\\TP3\\bank-additional\\bank-additional.csv",
  sep=",", header=TRUE)


dados$job <- as.numeric(dados$job)
dados$marital <- as.numeric(dados$marital)
dados$education <- as.numeric(dados$education) 
dados$default <- as.numeric(dados$default)
dados$housing <- as.numeric(dados$housing)
dados$loan <- as.numeric(dados$loan)
dados$contact <- as.numeric(dados$contact)
dados$month <- as.numeric(dados$month)
dados$day_of_week <- as.numeric(dados$day_of_week)
dados$poutcome <- as.numeric(dados$poutcome)
dados$y <- as.numeric(dados$y)

#normalizar entre -1 e 1
dados$age <- (dados$age - (max(dados$age)+min(dados$age))/2)/((max(dados$age)-min(dados$age))/2)
dados$job <- (dados$job - (max(dados$job)+min(dados$job))/2)/((max(dados$job)-min(dados$job))/2)
dados$marital <- (dados$marital - (max(dados$marital)+min(dados$marital))/2)/((max(dados$marital)-min(dados$marital))/2)
dados$education <- (dados$education - (max(dados$education)+min(dados$education))/2)/((max(dados$education)-min(dados$education))/2)
dados$housing <- (dados$housing - (max(dados$housing)+min(dados$housing))/2)/((max(dados$housing)-min(dados$housing))/2)
dados$loan <- (dados$loan - (max(dados$loan)+min(dados$loan))/2)/((max(dados$loan)-min(dados$loan))/2)
dados$month <- (dados$month - (max(dados$month)+min(dados$month))/2)/((max(dados$month)-min(dados$month))/2)
dados$day_of_week <- (dados$day_of_week - (max(dados$day_of_week)+min(dados$day_of_week))/2)/((max(dados$day_of_week)-min(dados$day_of_week))/2)
dados$campaign <- (dados$campaign - (max(dados$campaign)+min(dados$campaign))/2)/((max(dados$campaign)-min(dados$campaign))/2)
dados$poutcome <- (dados$poutcome - (max(dados$poutcome)+min(dados$poutcome))/2)/((max(dados$poutcome)-min(dados$poutcome))/2)
dados$emp.var.rate <- (dados$emp.var.rate - (max(dados$emp.var.rate)+min(dados$emp.var.rate))/2)/((max(dados$emp.var.rate)-min(dados$emp.var.rate))/2)
dados$cons.price.idx <- (dados$cons.price.idx - (max(dados$cons.price.idx)+min(dados$cons.price.idx))/2)/((max(dados$cons.price.idx)-min(dados$cons.price.idx))/2)
dados$cons.conf.idx <- (dados$cons.conf.idx - (max(dados$cons.conf.idx)+min(dados$cons.conf.idx))/2)/((max(dados$cons.conf.idx)-min(dados$cons.conf.idx))/2)
dados$euribor3m <- (dados$euribor3m - (max(dados$euribor3m)+min(dados$euribor3m))/2)/((max(dados$euribor3m)-min(dados$euribor3m))/2)
dados$nr.employed <- (dados$nr.employed - (max(dados$nr.employed)+min(dados$nr.employed))/2)/((max(dados$nr.employed)-min(dados$nr.employed))/2)

treino <- dados[1:3001,]
teste <- dados[3002:4119,]

funcao <- y ~ age+job+marital+education+housing+loan+month+day_of_week+campaign+poutcome+emp.var.rate+cons.price.idx+cons.conf.idx+euribor3m+nr.employed

selecao <- regsubsets(funcao,dados)
summary(selecao)
#selecao: age, education, month, poutcome, emp.var.rate, cons.price.idx, euribor3m, nr.employed

formula <- y ~ age+education+month+poutcome+emp.var.rate+cons.price.idx+euribor3m+nr.employed


#Treino e teste da RNA
rna <- neuralnet( formula,treino,hidden=c(4, 2), lifesign="full", threshold=0.1)
#2416 steps, 10 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.314
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 148.9
ssq(c(teste$y),c(resultados$previsao))
#resultado: 110
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 52 entradas com o valor de 2 -> "yes", cerca de 4,65%

#Treino e teste da RNA
rna <- neuralnet( formula,treino, lifesign="full", threshold=0.1)
#6416 steps, 7 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.308
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 184.6
ssq(c(teste$y),c(resultados$previsao))
#resultado: 106
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 32 entradas com o valor de 2 -> "yes", cerca de 2,86%

#Treino e teste da RNA
rna <- neuralnet( formula,treino, hidden=c(10,5) ,lifesign="full", threshold=0.1)
#N�o convergiu

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "rprop-", lifesign="full", threshold=0.1)
#step: 5100, 20segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.309
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 154.1
ssq(c(teste$y),c(resultados$previsao))
#resultado: 107
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 47 entradas com o valor de 2 -> "yes", cerca de 4,2%

#Mudan�a da topologia
rna <- neuralnet( formula,treino,hidden=c(8, 4, 2), algorithm = "rprop-", lifesign="full", threshold=0.1)
#step: 5669 e 50 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.328
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 150.1
ssq(c(teste$y),c(resultados$previsao))
#resultado: 120
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 56 entradas com o valor de 2 -> "yes", cerca de 5%

rna <- neuralnet( formula,treino, algorithm = "rprop-", lifesign="full", threshold=0.1)
#step: 8010 e 9 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.312
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 174.5
ssq(c(teste$y),c(resultados$previsao))
#resultado: 109
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 37 entradas com o valor de 2 -> "yes", cerca de 3,39%

rna <- neuralnet( formula,treino,hidden=c(4, 2), algorithm = "sag", lifesign="full", threshold=0.15)
#n�o convergiu com threshold de 10%
#steps 7311 e 30 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.315
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 163.8
ssq(c(teste$y),c(resultados$previsao))
#resultado: 111
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 43 entradas com o valor de 2 -> "yes", cerca de 3,85%

rna <- neuralnet( formula,treino, hidden=c(4,2), algorithm = "slr", lifesign="full", threshold=0.1)
#steps 6695 e 25 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.317
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 174.6
ssq(c(teste$y),c(resultados$previsao))
#resultado: 112
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 38 entradas com o valor de 2 -> "yes", cerca de 3,39%

#Mudan�a da topologia
rna <- neuralnet( formula,treino, hidden=c(8), algorithm = "slr", lifesign="full", threshold=0.15)
#N�o convergiu

rna <- neuralnet( formula,treino, hidden=c(2), algorithm = "slr", lifesign="full", threshold=0.1)
#N�o convergiu

rna <- neuralnet( formula,treino, hidden=c(4,2,2), algorithm = "slr", lifesign="full", threshold=0.1)
#steps 1016 e 5 segundos
teste.sub <- subset(teste, select = c("age","education","month","poutcome","emp.var.rate","cons.price.idx","euribor3m","nr.employed"))
rna.resultados <- compute(rna,teste.sub)
resultados <- data.frame(atual=teste$y,previsao=rna.resultados$net.result)
resultados$previsao <- round(resultados$previsao,digits = 0)
rmse(c(teste$y),c(resultados$previsao))
#resultado: 0.319
nrmse(c(teste$y),c(resultados$previsao))
#resultado: 146,3
ssq(c(teste$y),c(resultados$previsao))
#resultado: 114
diferentes <- resultados$previsao[resultados$previsao != 1]
#possui cerca de 56 entradas com o valor de 2 -> "yes", cerca de 5%
